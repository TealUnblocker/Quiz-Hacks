<script lang="ts">
    import Group from "../../hud/Group.svelte";
    import AutoBuild from "./AutoBuild.svelte";
    import HidePopups from "./HidePopups.svelte";
</script>

<Group name="The Floor is Lava">
    <AutoBuild />
    <HidePopups />
</Group>